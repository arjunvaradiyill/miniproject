var db=require('../config/connection')
var collection=require('../config/collection')
//var dbo = db.get();
module.exports={
    addBusiness:(businesses,callback)=>{
        
        db.get().collection('business').insertOne(businesses).then((data)=>{
           // console.log(data);
            callback(data)
        })
    },
    getAllBusiness:()=>{
        return new Promise(async(resolve,reject)=>{
            let business=await db.get().collection(collection.BUSINESS_COLLECTION).find().toArray()
            resolve(business)
        })
    }
}  


