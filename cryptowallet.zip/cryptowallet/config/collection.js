module.exports={
    BUSINESS_COLLECTION:'business'
}