var express = require('express');
var router = express.Router();
//var app = express();
var MongoClient=require('mongodb').MongoClient
/* GET users listing. 
router.get('/', function(req, res, next) {
 
    res.render('add');
});
router.post('/',(req,res)=>{
    
    console.log(req.body);


})
module.exports = router;*/
