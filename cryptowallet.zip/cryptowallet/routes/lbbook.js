var express = require('express');
var router = express.Router();
var businessHelpers = require('../helpers/business-helpers')
/* GET users listing. */
router.get('/', function(req, res, next) {
   
    businessHelpers.getAllBusiness().then((business)=>{
        res.render('lbbook',{business});
    })
    
});


router.get('/add', function(req, res, next) {
 
    res.render('add');
});

router.post('/add',(req,res)=>{
    //res.send('sanjo')
    //console.log(req.body);
    businessHelpers.addBusiness(req.body,(result)=>{
        res.send("data submitted successfully")
    })

})



module.exports = router;